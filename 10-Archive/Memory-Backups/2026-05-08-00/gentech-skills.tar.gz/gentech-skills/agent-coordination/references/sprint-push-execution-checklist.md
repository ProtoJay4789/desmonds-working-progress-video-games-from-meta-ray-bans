# Sprint Push Execution Checklist

**Purpose:** End-to-end checklist for activating a sprint push when Jordan confirms "let's go" on a deadline-driven project. Combines health check, handoff creation, specialist activation, and tracking into one sequence.

**Trigger:** Jordan says "let's push", "let's get it", "go", or similar activation language after a status briefing.

## Execution Sequence (10 minutes)

### Step 1: Agent Health Check (30s)
```bash
ps aux | grep -E 'hermes|yoyo|dmob|desmond|gentech' | grep -v grep
```
- All agents running? → Proceed
- Any agent down? → Health check protocol (section 2.7), note who's offline before proceeding

### Step 2: Create Green Room Handoff (2 min)
- File: `09-Green Room/active-handoffs/YYYY-MM-DD-{project}-sprint-push.md`
- Include: current state (done/not done), P0 tasks per department, blockers, sponsor integrations, repo paths
- Use the sprint plan as source of truth for task lists

### Step 3: Send Sprint Briefings (5 min)
- **DMOB** → `telegram:-1003872552815` (Labs)
- **Desmond** → `telegram:-1003893562036` (Creative)
- **YoYo** → `telegram:-1002916759037` (Strategies) — only if strategy work needed

Each briefing follows template from section 4.5:
- Jordan confirmation line
- Deadline + days remaining
- P0 tasks (specific, actionable, with file paths)
- What's already built (so they don't redo work)
- Known blockers
- Request ACK + ETA

### Step 4: Update Tracking (2 min)
- Update sprint progress log: `09-Green Room/active-handoffs/sprint-progress-log.md`
- Add timestamp, Jordan confirmation, sent briefings, status checkpoints
- Create/update tracking table with day-by-day breakdown per department

### Step 5: Relay ACKs (ongoing)
- When specialists respond, relay their confirmations and ETAs to Jordan
- Flag any blockers they raise immediately

## Common Patterns

### "Side quest" = Sidetracks
Jordan uses "side quest" to refer to additional prize tracks within a hackathon (e.g. Zerion $5K, GoldRush $3K sidetracks within Colosseum Frontier). Don't confuse with separate hackathons.

### Status Briefing → Activation Flow
1. Load hackathon skill → check vault + repo state
2. Present honest status (done/not done/blockers)
3. Jordan confirms → sprint push activated
4. Follow this checklist

### Demo Video Blocker Pattern
Demo video is almost always blocked on devnet deployment. Brief creative team on storyboard + script FIRST, video recording as P1 after deploy is live.
