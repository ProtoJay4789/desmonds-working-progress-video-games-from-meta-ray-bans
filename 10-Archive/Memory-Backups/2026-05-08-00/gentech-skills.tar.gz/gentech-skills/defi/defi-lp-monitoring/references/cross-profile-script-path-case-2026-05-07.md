# Cross-Profile Script Path & Suppress-Until-Resolution Pattern
## Session: 2026-05-07 (Jordan + Gentech)

### Problem
Cron job `e00b46103b08` in Desmond's profile was failing with:
```
Script not found: /root/.hermes/profiles/desmond/scripts/d5-lp-consolidated.py
```

The script existed at `/root/.hermes/scripts/d5-lp-consolidated.py` (shared scripts directory) but Desmond's profile had no symlink to it.

### Root Cause
Each Hermes profile has an isolated scripts directory. Cron jobs reference scripts relative to their profile's context, not the global shared directory. When a job in Profile A uses a script from Profile B, it fails unless a symlink or copy exists.

### Solution
```bash
mkdir -p /root/.hermes/profiles/desmond/scripts
ln -sf /root/.hermes/scripts/d5-lp-consolidated.py /root/.hermes/profiles/desmond/scripts/d5-lp-consolidated.py
```

### Alert Logic Update
Jordan clarified the desired behavior for the 10-minute LP monitor:

**Before:** Alert with 5-minute debounce, then rate-limit to once per 5 minutes (could spam alerts)

**After (Jordan's rule):**
- Below 30% fee efficiency → ONE notification, then silent until efficiency recovers above 30%
- Breaking out of range → wait 5 minutes to confirm, ONE notification, then silent until price returns to range
- "After that, everything else could be silent until there's an action done"

### Implementation
Added `oor_alerted` and `eff_alerted` boolean flags to state file. These flags:
1. Set to `true` when an alert is sent
2. Reset to `false` only when the condition resolves (price returns to range / efficiency recovers above 30%)
3. Prevent re-alerting for the same condition instance

### Files Modified
- `/root/.hermes/scripts/d5-lp-consolidated.py` — updated `check_alerts()` function
- `/root/.hermes/scripts/.lfj-defi-state.json` — added new state fields
- `/root/vaults/gentech/03-Strategies/scripts/d5-lp-consolidated.py` — synced vault copy

### Current LP Position (at time of fix)
- Price: $9.49 (in range $9.45–$9.74)
- Efficiency: 30.6% (borderline — just above 30% threshold)
- Shape: CURVE
- Status: ✅ Running correctly from Desmond profile
