# Colosseum Frontier — Program Account Layouts

Cross-program byte offsets for manual deserialization (Anchor structs with 8-byte discriminator).

## job-escrow: JobAccount

Program ID: `HqpwrZDaoLtNkhsdM8XqX3UPDDozrWLnNF2q6FrD95vH`

```
Offset  Size  Field              Type
------  ----  -----              ----
0       8     discriminator      [u8; 8] (Anchor default)
8       8     job_id             u64
16      32    poster             Pubkey
48      32    worker             Pubkey (Pubkey::default() if unassigned)
80      512   description        [u8; 512]
592     2     description_len    u16
594     1024  requirements       [u8; 1024]
1618    2     requirements_len   u16
1620    8     payment_lamports   u64
1628    8     deadline           i64
1636    1     status             JobStatus (borsh enum: 1 byte)
1637    256   deliverable        [u8; 256]
1893    2     deliverable_len    u16
1895    8     created_at         i64
1903    8     updated_at         i64
1911    1     bump               u8
```

### JobStatus Enum (borsh, 1 byte)

```
0 = Open
1 = Accepted
2 = Submitted
3 = Approved
4 = Disputed
5 = Expired
6 = Refunded
7 = Completed
```

## dispute-resolver: DisputeAccount

Program ID: `wtPxD8z3K2C515cZaB5CCN4BNmuX4ahhNpvYJn2HCo1`

```
Offset  Size  Field              Type
------  ----  -----              ----
0       8     discriminator
8       32    job                Pubkey
40      32    initiator          Pubkey
72      32    poster             Pubkey
104     32    worker             Pubkey
136     1024  reason             [u8; 1024]
1160    2     reason_len         u16
1162    1024  resolution         [u8; 1024]
2186    2     resolution_len     u16
2188    1     outcome            Option<u8> (0=None, 1=PosterWin, 2=WorkerWin, 3=Split)
2189    1     status             DisputeStatus
2190    1     resolved           bool
2191    8     created_at         i64
2199    8     resolved_at        i64
2207    1     bump               u8
```

## reputation: ReputationNft

Program ID: `9CDr7iJrrKvzdxFMmK156EFEHKdXR2jiDDCVqLSX79rb`

```
Offset  Size  Field              Type
------  ----  -----              ----
0       8     discriminator
8       32    agent              Pubkey
40      1     tier               ReputationTier (borsh: 0=Scout,1=Rookie,2=Pro,3=Legend)
41      4     total_ratings      u32
45      8     total_score_sum    u64
53      32    asset_id           Pubkey
85      8     minted_at          i64
93      8     updated_at         i64
101     1     bump               u8
```

## Usage Notes

- Offsets include the 8-byte Anchor discriminator
- Borsh serialization: u64/u16/i64 are little-endian, Pubkey is raw 32 bytes
- Enum variants are 1-byte indices (borsh default)
- Option<T>: 0x00 = None, 0x01 + T bytes = Some(T)
- Always check `data.len() >= expected_min_size` before reading
