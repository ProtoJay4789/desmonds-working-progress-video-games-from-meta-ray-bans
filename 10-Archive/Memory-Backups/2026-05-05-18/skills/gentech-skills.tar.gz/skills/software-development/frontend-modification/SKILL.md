---
name: frontend-modification
title: Frontend Modification with Embedded JavaScript
description: Skill for safely modifying HTML files with embedded JavaScript, particularly when dealing with complex data structures or escaping issues. Provides workarounds for common pitfalls when using the patch tool with HTML/JS files.
---
# Frontend Modification Skill

## Overview
Skill for safely modifying HTML files with embedded JavaScript, particularly when dealing with complex data structures or escaping issues. This skill provides workarounds for common pitfalls when using the `patch` tool with HTML/JS files.

## When to Use
- Modifying HTML files that contain inline JavaScript
- Inserting JSON data into script tags
- Working around `patch` tool escape-drift issues
- Breaking down complex file modifications into manageable steps

## Steps

### 1. Assess the File Structure
Before making changes, read the entire HTML file to understand:
- The overall structure and sections
- Where you need to insert content
- Existing script blocks and their locations

### 2. Use Python for Complex Modifications
When the `patch` tool fails due to escape-drift or complex string matching, use Python's file manipulation capabilities:

```python
# Read the file
with open('file.html', 'r') as f:
    content = f.read()

# Make modifications
# ... your logic here ...

# Write back
with open('file.html', 'w') as f:
    f.write(modified_content)
```

### 3. Break Down Large Insertions
For large JavaScript blocks with embedded data:
- Insert the HTML structure first (without the script content)
- Then add the script content separately
- Use clear markers to identify insertion points

### 4. Handle JSON Data in Scripts
When embedding JSON data in a script tag:
- Load the JSON data from a file or generate it
- Convert to a compact string representation
- Escape quotes properly if needed
- Insert as a raw string in the script template

### 5. Verify Changes
After modification:
- Read back the file to ensure content is correct
- Check for syntax errors in JavaScript
- Test that the page still renders properly

## Pitfalls
- **Escape-drift**: The `patch` tool may fail if the old_string contains backslashes that aren't in the file. Use Python for complex cases.
- **Partial views**: When using pagination with `read_file`, you might not get the full context. Read the entire file for critical modifications.
- **Overwriting**: Be careful not to overwrite entire sections unintentionally. Use precise insertion points.

## Example Workflow
1. Read the HTML file completely
2. Identify the insertion point (e.g., before a specific section)
3. Create the new HTML content as a string
4. Insert the HTML structure
5. Create the JavaScript with embedded JSON
6. Insert the script tag
7. Write the modified file
8. Verify the changes

## Tools Used
- `execute_code` with Python for file manipulation
- `read_file` for inspecting file content
- `patch` for simple text replacements
- `search_files` for finding specific patterns

## Related Skills
- `gentech-project-coordination`: For overall project coordination
- `html-embedding`: For embedding data in HTML (this skill)
- `javascript-integration`: For integrating JavaScript with web pages