#!/usr/bin/env python3
"""
Verify D5 milestone thresholds are consistent across all D5 monitoring files.
Usage: python3 verify_milestone_consistency.py

Checks:
  - .lfj-aae-config.json (milestones array)
  - d5-master-cron.py (MILESTONES list)
  - defi-milestone-summary.py (MILESTONES list)
  - lp-aae-signal-monitor.py (DEFAULT_CONFIG milestones)
  - lp-unified-monitor.py (MILESTONES list, optional)

All files must define the same 5-tier ladder:
  Scout: 5.0, Raider: 20.0, Warlord: 50.0, Sovereign: 100.0, Freedom: 200.0
"""

import json
import re
import sys
from pathlib import Path

BASE = Path("/root/vaults/gentech/03-Strategies/scripts")
FILES = {
    "config": BASE / ".lfj-aae-config.json",
    "master_cron": BASE / "d5-master-cron.py",
    "summary": BASE / "defi-milestone-summary.py",
    "signal_monitor": BASE / "lp-aae-signal-monitor.py",
    "unified_monitor": BASE / "lp-unified-monitor.py",
}

EXPECTED = [
    {"tier": 1, "label": "Scout",     "daily_fees": 5.0},
    {"tier": 2, "label": "Raider",    "daily_fees": 20.0},
    {"tier": 3, "label": "Warlord",   "daily_fees": 50.0},
    {"tier": 4, "label": "Sovereign", "daily_fees": 100.0},
    {"tier": 5, "label": "Freedom",   "daily_fees": 200.0},
]

def extract_json_array(text: str):
    """Extract first JSON array from text (handles Python-style single quotes loosely)."""
    # Find the start of array
    start = text.find('[')
    if start == -1:
        return None
    # Try to parse JSON by fixing single quotes if needed
    candidate = text[start:]
    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        # Try converting single quotes to double
        fixed = candidate.replace("'", '"')
        try:
            return json.loads(fixed)
        except json.JSONDecodeError:
            return None

def parse_python_milestones(text: str) -> list:
    """Parse Python MILESTONES = [...] block."""
    match = re.search(r'MILESTONES\s*=\s*(\[.*?\])(?:\s*$|\n)', text, re.DOTALL)
    if not match:
        return None
    raw = match.group(1)
    # Replace Python single quotes with double for JSON
    raw = raw.replace("'", '"')
    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        print(f"JSON parse failed: {e}")
        return None

def check_file(path: Path, extractor) -> (list, str):
    if not path.exists():
        return None, f"missing"
    try:
        text = path.read_text()
        items = extractor(text)
        if items is None:
            return None, f"parse-failed"
        return items, "ok"
    except Exception as e:
        return None, f"error: {e}"

def normalize(items: list) -> list:
    return [{"tier": i["tier"], "label": i["label"], "daily_fees": float(i["daily_fees"])} for i in items]

def main():
    results = {}
    for name, path in FILES.items():
        if name == "config":
            items, status = check_file(path, lambda t: json.loads(t).get("milestones", []))
        else:
            items, status = check_file(path, parse_python_milestones)
        results[name] = {"items": items, "status": status}

    # Print status
    print("=== Milestone Threshold Audit ===")
    all_ok = True
    for name, result in results.items():
        if result["status"] != "ok":
            print(f"❌ {name}: {result['status']}")
            all_ok = False
        else:
            norm = normalize(result["items"])
            labels = [f"{i['label']}:{i['daily_fees']}" for i in norm]
            print(f"✅ {name}: {', '.join(labels)}")
            if norm != EXPECTED:
                all_ok = False
                print(f"   ⚠ Mismatch vs expected")
                for exp, got in zip(EXPECTED, norm):
                    if exp != got:
                        print(f"   Expected {exp} but got {got}")

    if all_ok:
        print("\n🎉 All files consistent with 5-tier D5 ladder.")
        return 0
    else:
        print("\n⚠ Inconsistencies detected. Review the file blocks above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
