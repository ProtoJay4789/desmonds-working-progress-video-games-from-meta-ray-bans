---
name: hackathon-prep
description: "Blockchain hackathon preparation: research, dev tools, smart contract audits, gap analysis, sprint reviews, and submission workflows."
version: 1.0.0
author: Hermes Agent Curator
license: MIT
metadata:
  hermes:
    tags: [hackathon, research, dev-tools, audit, sprint, submission]
    related_skills: []
---

# Blockchain Hackathon Preparation

End-to-end workflow for hackathon preparation: research, environment setup, codebase audit, security review, gap analysis, and sprint planning.

---

## 0. One Product, Multi-Hackathon Strategy

**Core principle (Jordan, May 2026):** Build one product, interchange it for different hackathons. Don't rebuild from scratch — adapt the same codebase.

### How It Works
1. **Build the canonical product** — AgentEscrow / AAE Brain on the primary chain (Solana or EVM)
2. **For each hackathon:** Deploy the same contract logic on the target chain, adjust the narrative to match the track, write chain-specific integration code
3. **Reuse:** Core contracts, test suite, demo video template, submission docs structure
4. **Adapt:** Chain-specific deployment scripts, SDK integrations, sponsor tool hooks

### What Changes Per Hackathon
| Element | Stays the Same | Changes |
|---------|---------------|---------|
| Core logic | ✅ Contract architecture, business logic | — |
| Test suite | ✅ Most tests (unit/integration) | Chain-specific deployment tests |
| Demo | ✅ Same core demo flow | UI tweaks, chain-specific wallets |
| Narrative | ✅ "Agent labor market" story | Track-specific framing (e.g., "Agentic Commerce" for Kite AI) |
| Submission docs | — | Platform-specific format (Devpost vs Cantina) |

### Quick Deadline Triage

When asked "which project is due first?" or "what's the sprint look like?":

```bash
# Pull both tracking files
cat /root/vaults/gentech/01-Agency/active-hackathons.md
cat /root/vaults/gentech/02-Labs/Bug-Bounties/00-Active-Bounties.md
```

Sort by deadline ascending. Present as a prioritized list with days remaining. Flag anything within 7 days as urgent.

---

## 1. Hackathon Research Tracking

Research a hackathon from web sources, assess fit for GenTech's AAE narrative, and update all vault tracking files. This is the **pre-development phase** — happens before any code audit or building.

### When to Use
- Jordan says "add X hackathon" or "research Y hackathon"
- Jordan says "check the status of Z" for a hackathon
- A new hackathon appears on the radar
- Need to verify current details (dates, prizes, requirements) for an already-tracked hackathon
- Updating the active hackathons table in HQ after a change

### Phase 1: Research the Hackathon

#### Colosseum Copilot API (for Solana hackathons)

```bash
# API base: https://copilot.colosseum.com/api/v1
# Token: ~/.hermes/scripts/colosseum-config.json
# Docs: https://docs.colosseum.com/copilot/api-reference

# Search for hackathon projects
curl -X POST "$COLOSSEUM_COPILOT_API_BASE/search/projects" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"query": "agent payments solana"}'

# Get project details by slug
curl "$COLOSSEUM_COPILOT_API_BASE/projects/by-slug/agentescrow" \
  -H "Authorization: Bearer $TOKEN"

# Analyze a project
curl -X POST "$COLOSSEUM_COPILOT_API_BASE/analyze" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"project_ids": ["..."]}'
```

#### Browse the Source

```bash
# Most hackathons are on Devpost
# Navigate to the URL and extract:
# - Exact dates (start + end)
# - Prize pool breakdown
# - Requirements (what to build, tech stack)
# - Team size limits
# - Submission requirements (hosted URL, repo, demo video)
# - Participant count
# - Partner/sponsor details
```

#### Key Data Points to Extract

| Field | Why It Matters |
|-------|---------------|
| Start/end dates | Timeline and sprint planning |
| Prize pool | ROI assessment |
| Tech requirements | Stack fit (Solana? EVM? Google Cloud?) |
| Submission format | What we need to produce |
| Team size | Solo vs. collaboration |
| Participant count | Competition level |
| Partner integrations | MCP servers, APIs we'd use |

### Phase 2: Vault Files to Update

There are **3 files** that need updating for any hackathon change:

#### 1. `01-Agency/active-hackathons.md`
- **Section-based**: Current Focus / Registered / Opportunistic / Skipped
- Move hackathon between sections as status changes
- Keep descriptions concise with key facts

#### 2. `02-Labs/Hackathon-Tracker.md`
- **Detailed entries**: Prize pool, dates, focus, relevance rating, status
- Numbered entries (### 1, ### 2, etc.)
- Status emojis: 🔴 PRIMARY / 🟢 ACTIVE / 🟡 REVIEW / ⏸️ SKIP / ⛔ DROPPED

#### 3. `03-Projects/HACKATHON-ROSTER-2026.md`
- **Table format**: Name | Deadline | Notes | Status
- Concise — one-liner per hackathon
- Sections: Active Focus / Watch for Future / Skipped

### Phase 3: Competitive Landscape Analysis

Before positioning our submission, map the competitive space across chains.

#### Colosseum Copilot — Search Competing Projects

```bash
TOKEN=$(jq -r .token ~/.hermes/scripts/colosseum-config.json)
BASE="https://copilot.colosseum.com/api/v1"

# Search by topic/technology
curl -s -X POST "$BASE/search/projects" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"query": "AI agent payments x402 escrow", "limit": 10}'

# Get cluster data (e.g., v1-c14 = Solana AI Agent Infrastructure)
curl -s "$BASE/clusters/v1-c14" -H "Authorization: Bearer $TOKEN"
```

Key fields per result: `slug`, `name`, `oneLiner`, `prize` (type/amount/placement), `tags` (problemTags, solutionTags, techStack), `crowdedness` (project count in cluster), `cluster.label`.

#### GitHub Search — Cross-Chain Competitors

```bash
# Base chain competitors
curl -s "https://api.github.com/search/repositories?q=agent+escrow+base+chain&sort=updated&order=desc&per_page=10"

# Avalanche competitors
curl -s "https://api.github.com/search/repositories?q=agent+escrow+avalanche&sort=updated&order=desc&per_page=10"

# x402 agent payments across chains
curl -s "https://api.github.com/search/repositories?q=x402+agent+payments+base+OR+avalanche&sort=updated&order=desc&per_page=10"
```

#### Competitive Matrix Template

Build a table comparing our project vs. competitors across dimensions:

| Feature | Competitor A | Competitor B | **Our Project** |
|---------|-------------|-------------|-----------------|
| Core capability (e.g., x402) | ✅ | ✅ | ✅ |
| Gap they don't fill | ❌ | ❌ | ✅ |

**Output**: Clear positioning statement — "Competitors solve X. We solve Y."

### References
- [Hackathon research template](references/hackathon-research-template.md)
- [Colosseum Copilot API guide](references/colosseum-api.md)

---

## 2. Environment Setup

### Install Dev Tools

```bash
# Foundry (EVM/Solidity)
curl -L https://foundry.paradigm.xyz | bash
source ~/.bashrc && ~/.foundry/bin/foundryup

# Solana CLI
sh -c "$(curl -sSfL https://release.anza.xyz/v2.1.21/install)"
export PATH="$HOME/.local/share/solana/install/active_release/bin:$PATH"
solana config set --url devnet

# Anchor via AVM (requires Rust)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
source ~/.cargo/env
cargo install --git https://github.com/coral-xyz/anchor avm --locked --force
avm install 0.30.1 && avm use 0.30.1

# Verify
forge --version && anchor --version && solana --version
```

### Clone Repos

```bash
mkdir -p ~/repos && cd ~/repos
git clone https://github.com/ORG/repo-name.git
```

### References
- [Dev tools setup guide](references/dev-tools-setup.md)

---

## 3. Codebase Audit

For each repo, run a parallel audit via `delegate_task`. Audit template:

```
Audit the [REPO] at ~/repos/[REPO]/. Read ALL contracts, tests, scripts, README, config.
Provide:
1. Contract inventory — what each does, lines, purpose
2. Test coverage — what's tested, what's missing
3. Security findings — list by severity (CRITICAL/HIGH/MEDIUM/LOW/INFO)
4. OpenZeppelin usage — correct? missing patterns?
5. Incomplete/stub functions
6. Deployment scripts — exist? correct?
7. Code quality rating (1-5 stars)
8. What's missing for hackathon submission
```

### Security Checklist (Solidity)

Every contract review MUST check:
- [ ] ReentrancyGuard on all state-changing functions with external calls
- [ ] Checks-Effects-Interactions pattern
- [ ] Access control (onlyOwner, roles, or signature verification)
- [ ] Integer overflow (Solidity 0.8+ has built-in, but check unchecked blocks)
- [ ] SafeERC20 for all token transfers
- [ ] Custom errors vs require strings (gas efficiency)
- [ ] Event emissions on state changes
- [ ] Signature replay protection (EIP-712 domain separator)
- [ ] Front-running vulnerabilities (especially for DEX-related contracts)
- [ ] Oracle manipulation risks
- [ ] Upgradeability patterns (if applicable)

### Security Checklist (Anchor/Solana)

- [ ] Signer checks on all privileged instructions
- [ ] Account validation (PDA seeds, bump seeds, owner checks)
- [ ] Rent exemption for all accounts
- [ ] Close account pattern (return rent to user)
- [ ] CPI guard checks
- [ ] No duplicate account reuse in same instruction

### Common Anchor Compilation Errors & Fixes

| Error | Cause | Fix |
|-------|-------|-----|
| Corrupted pubkeys (31 bytes instead of 32) | base58 address typo | Verify with Python: `import base58; print(len(base58.b58decode(addr)))` |
| Missing `solana_program` dependency | Not in Cargo.toml | Add `solana-program = "1.18"` |
| Missing derives on enums/structs | Missing `#[derive(InitSpace)]` or `Debug` | Add derives as needed |
| `u16` vs `usize` type mismatches | Constants defined as `usize` | Cast: `name_len <= MAX_NAME_LENGTH as u16` |
| Borrow checker violations in lamport transfers | Mutable borrow conflict | Get `AccountInfo` references BEFORE mutable borrow |
| `has_one` vs explicit constraint | Pubkey comparison failure | Replace with explicit constraint |
| Missing instruction arguments in `#[instruction]` | Argument used in PDA seeds | Add to `#[instruction(...)]` |
| Missing struct imports | Missing `use crate::state::{AGENT_SEED, AgentAccount};` | Add imports |
| Missing error variants | Variant not in `errors.rs` | Add variant to `errors.rs` |

### ⚠️ CRITICAL: Verify Repo State Before Accepting Sprint Plans

**Session lesson (May 5, 2026):** Sprint plan said "2 programs deployed to devnet, 2 in progress." Reality: 1 partially-built program with missing instruction files and no Solana CLI/Anchor installed. Never trust documentation over filesystem.

#### Pre-Sprint Verification Checklist
Before committing to any deadline or telling Jordan "we're on track":

```bash
# 1. Check toolchain
which anchor && anchor --version
which solana && solana --version
which forge && forge --version

# 2. Check actual program files exist (not just referenced in mod.rs)
find programs/ -name "*.rs" | sort
# Compare against what lib.rs and mod.rs reference — any missing files?

# 3. Check git history
git log --oneline -5
# If only 1-2 commits exist, be suspicious of "deployed" claims

# 4. Check for real tests (not boilerplate)
find tests/ -name "*.ts" -o -name "*.js" | xargs grep -l "it(" 2>/dev/null
# Boilerplate test files have no `it(` blocks

# 5. Check deploy artifacts
ls target/deploy/ 2>/dev/null
# If empty, nothing has been deployed

# 6. Check devnet deployment
solana program show <PROGRAM_ID> --url devnet 2>/dev/null
# If error, it's NOT deployed
```

#### Red Flags That Mean "Not Actually Built"
- Only 1-2 git commits on the repo
- `mod.rs` references instruction files that don't exist on disk
- Test file is boilerplate (`describe("program-name", () => { it("Is initialized!")`)
- No `target/deploy/` directory
- Anchor.toml only lists 1 program when plan says 4
- `which anchor` returns a broken symlink (points to avm but avm isn't functional)

#### When You Discover This
1. Report honestly to Jordan — "The repo state doesn't match the sprint plan"
2. Present actual vs claimed state in a clear table
3. Propose a realistic timeline with toolchain setup included
4. Don't sugarcoat — Jordan values honest assessments over optimistic updates

### References
- [Security audit template](templates/security-audit-template.md)
- [Anchor build-fix guide](references/anchor-build-fix.md)

---

## 4. Gap Analysis

Compare existing code against submission requirements:

| Requirement | Status | Effort | Priority |
|-------------|--------|--------|----------|
| [feature] | ✅ Done / ❌ Missing / ⚠️ Partial | [hours] | 🔴/🟡/🟢 |

### Time Estimation Rule of Thumb

- Fix security issue: 30min-2hr
- Port Solidity → Anchor: 4-6hr per contract
- Build demo UI: 4-8hr
- Write submission docs: 2-3hr
- Record demo video: 2-4hr
- Deploy to testnet: 1-2hr

### Sprint Planning

```
Available hours = days remaining × productive hours/day (usually 4)
If total effort > available hours → prioritize:
1. Security fixes (always first)
2. Core contracts (Registry, Escrow)
3. Deployment + tests
4. Demo UI
5. Documentation
6. Nice-to-haves
```

### References
- [Gap analysis template](templates/gap-analysis-template.md)

---

## 5. Mid-Hackathon Sprint Review

When work is already in progress and you need a status check — NOT a fresh audit. Trigger: Jordan says "review", "what's left", "sprint status", or "what are we looking at".

### Step 1: Pull Existing Audit Reports

```bash
# Find latest audit files
ls -lt /root/vaults/gentech/02-Labs/Audit-*.md | head -5
```

### Step 2: Check Repo State

```bash
cd ~/repos/[REPO]
git log --oneline -5           # Recent commits
git status --short             # Uncommitted changes
forge test --summary           # Current test count + pass/fail
```

### Step 3: Verify Deploy Readiness

```bash
# Check deploy script exists and is configured
cat scripts/Deploy.s.sol
cat foundry.toml               # RPC endpoints, chain ID, explorer config
```

### Step 4: Produce Sprint Summary

Use this template:

```markdown
## [Project] — Current State

**Repo:** [name] | **Deadline:** [date] | **Tests:** X/Y ✅

### ✅ Done
| Item | Status |
|------|--------|
| [contract/feature] | ✅ [notes] |

### ❌ What's Left
| Item | Effort | Blocker? |
|------|--------|----------|
| [task] | [hours] | 🔴/🟡 |

### 🎯 The Sprint (X days remaining)
[Day-by-day plan]
```

### References
- [Sprint review template](templates/sprint-review-template.md)
